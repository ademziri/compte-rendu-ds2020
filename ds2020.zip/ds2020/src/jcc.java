public class jcc {
    private film[] competition;
    private int anne;
    private static final int nmax=30;
    private static int nbf;

    public jcc(int anne) {
        this.anne = anne;
        competition = new film[nmax];
        nbf = 0;

    }
    public void ajoutfilm(film f) {
        if (nbf < nmax) {
            competition[nbf++] = f;
        }
        else{
            System.out.println("le nombre de film maximale est atteint");
        }
    }

    public void listefilmsjcc(){
        for(int i=0;i<nbf;i++){
            System.out.println(competition[i]);
        }
    }

    public float totalvente(){
        float sum=0;
        for(int i=0;i<nbf;i++){
          sum=sum+competition[i].totalventebillets();

        }
        return sum;
    }


}
