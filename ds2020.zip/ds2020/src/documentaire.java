public class documentaire extends film{
    private String sujet;
    private static final float tarif=2;

    public documentaire(String titre, String realisateur, String pays, int minutes, String sujet) {
        super(titre, realisateur, pays, minutes);
        this.sujet = sujet;
    }
    public String toString(){
        return super.tostring()+"sujet; "+sujet;
    }


    public float totalventebillets() {

        return tarif*super.getNbrplace();

    }
}
