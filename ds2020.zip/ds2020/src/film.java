import java.util.Scanner;
public class film {
    protected String titre;
    protected String realisateur;
    protected String pays;
    protected int minutes;
    protected int nbrplace;

    public film(String titre, String realisateur, String pays, int minutes) {
        this.titre = titre;
        this.realisateur = realisateur;
        this.pays = pays;
        this.minutes = minutes;
    }

    public int getNbrplace() {
            return nbrplace;
    }

    public void setNbrplace(int nbrplace) {
        this.nbrplace = nbrplace;
    }

    public String tostring() {
        return titre+" de "+realisateur+" ( "+pays+" ) - "+minutes+" minutes ";
    }

    public float totalventebillets(){
        Scanner sc = new Scanner(System.in);
        System.out.println("nombre de place pour les etudiants ");
        int nbretud = sc.nextInt();
        int nbrpublic= nbrplace-nbretud;

        return(nbrpublic*3)+(nbretud*2);

    }




}
